package com.pages;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EcommercePage {
	
	
	private WebDriver driver;
	
	 // Locators for login
	
    private By usernameField = By.id("Email");
    private By passwordField = By.id("Password");
    private By loginButton = By.xpath("//input[@value='Log in']");

    // Locators for shopping cart
    private By cartButton = By.xpath("(//input[@value='Add to cart'])[5]");
    private By isCart = By.xpath("//div[contains(text(),'Your Shopping Cart is empty! ')]");
    private By addToCart=By.xpath("//input[contains(@data-productid,'74')]");
    private By isProduct=By.xpath("//p[contains(text(),'The product has been added to your')]");
    private By shoppingCart=By.xpath("//span[normalize-space()='Shopping cart']");
    private By itemPrice=By.xpath("//span[@class='product-price order-total']");
    private By removeproduct=By.xpath("//td[@class='remove-from-cart'][1]");
    private By updateCart=By.xpath("//input[@name='updatecart']");
    
    // Locators for wishlist
    private By wishlistCat=By.xpath("//ul[@class='top-menu']//a[normalize-space()='Electronics']");
    private By wishlistSub=By.xpath("//img[@title='Show products in category Cell phones']");
    private By phoneCover=By.xpath("//h2[@class='product-title']//a[normalize-space()='Phone Cover']");
    private By wishlistButton = By.xpath("//input[contains(@class,'button-2 add-to-wishlist-button')]");
    private By wishlistItemMsg = By.xpath("//p[contains(text(),'The product has been added to your')]");
    private By wishlist=By.xpath("//span[normalize-space()='Wishlist']");
    private By wishlistEmptyMessage = By.xpath("//div[contains(text(),'The wishlist is empty!')]");
    private By wishlistProductDetails=By.xpath("//td[@class='product']/a"); 
    private By removeItem=By.xpath("//tbody/tr[1]/td[1]/input[1]");
    private By updateWishlist=By.xpath("//input[contains(@value,'Update wishlist')]");
	

	private WebDriverWait wait;
    
    public EcommercePage(WebDriver driver) {
    	this.driver = driver;
        this.wait = new WebDriverWait(driver, 10); // Adjust timeout as necessary
    }


    public void enterusername(String username) {
		// TODO Auto-generated method stub
		WebElement usernameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField));
        usernameInput.clear();
		usernameInput.sendKeys(username);

	}

	public void enterpassword(String password) {
		// TODO Auto-generated method stub
		WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(passwordField));
        passwordInput.clear();
		passwordInput.sendKeys(password);
	}
	
	public void login() {
		driver.findElement(loginButton).click();
		
	}

    // Cart methods
		public void addItemToCart() throws InterruptedException {
		    // Wait for the cart button to be clickable and then click it
		    WebDriverWait wait = new WebDriverWait(driver, 10);  // Explicit wait of 10 seconds (adjust as needed)
		    wait.until(ExpectedConditions.elementToBeClickable(cartButton)).click();

		    Thread.sleep(10000);
		    // Wait for the 'Add to Cart' button to be visible and clickable
		    WebElement cart = driver.findElement(addToCart);

		    // Scroll the 'Add to Cart' button into view before clicking it
		    JavascriptExecutor js = (JavascriptExecutor) driver;
		    js.executeScript("arguments[0].scrollIntoView(true);", cart);
		    
		    Thread.sleep(10000);
		    // Wait until the 'Add to Cart' button is clickable before clicking it
		    wait.until(ExpectedConditions.elementToBeClickable(cart)).click();
		

	}


	public boolean isItemInCart() {
	    try {
	        // Wait until the "Product Added" confirmation message is visible
	        WebElement confirmationMessage = new WebDriverWait(driver, 20)  // 10 seconds timeout
	                .until(ExpectedConditions.visibilityOfElementLocated(isProduct));
	        
	        // If the confirmation message is found, it means the item was successfully added to the cart
	        return confirmationMessage.isDisplayed();  // Return true if the message is displayed
	    } catch (NoSuchElementException  e) {
	        // If the message is not found or the timeout is exceeded, return false
	        return false;
	    }
	}
    

    public void goToCart() throws InterruptedException {
    	
        driver.findElement(shoppingCart).click();
        Thread.sleep(5000);
    }
    
    public boolean viewCart() {
        try {
            // Try to find the element using XPath
            WebElement cartElement = driver.findElement(By.xpath("//h1[normalize-space()='Build your own computer']"));
            System.out.println(cartElement);
            // Check if the element is displayed (visible)
            return cartElement.isDisplayed();
        } catch (NoSuchElementException e) {
            // If element is not found, return false
            return false;
        }
    }


    public boolean isCartEmpty() {
    	try {
        WebElement itemCountText = driver.findElement(isCart);
        System.out.println("In Page" +itemCountText.getText());
        return itemCountText.isDisplayed();
       
    	}catch(NoSuchElementException e) {
            // If element is not found, return false
            return false;
    	}
    }
    
    public String getItemPrice() {
		String price=driver.findElement(itemPrice).getText();
		return (price);
		
	}

    // Wishlist methods
    public void addProductToWishlist() throws InterruptedException {
    	Thread.sleep(5000);
    	
    	WebDriverWait wait = new WebDriverWait(driver, 10);  // Explicit wait of 10 seconds (adjust as needed)
	    wait.until(ExpectedConditions.elementToBeClickable(wishlistCat)).click();

	    WebDriverWait wait1 = new WebDriverWait(driver, 10);  // Explicit wait of 10 seconds (adjust as needed)
	    wait1.until(ExpectedConditions.elementToBeClickable(wishlistSub)).click();

	    WebDriverWait wait2 = new WebDriverWait(driver, 10);  // Explicit wait of 10 seconds (adjust as needed)
	    wait2.until(ExpectedConditions.elementToBeClickable(phoneCover)).click();
	    
    	 WebElement addToWishlistBtn = driver.findElement(wishlistButton);
         addToWishlistBtn.click();
         Thread.sleep(2000);
         
    }
    
    public boolean isProductInWishlist() throws InterruptedException {
    	 try {
 	        // Wait until the "Product Added" confirmation message is visible
 	        WebElement confirmationMessage = new WebDriverWait(driver, 20)  // 10 seconds timeout
 	                .until(ExpectedConditions.visibilityOfElementLocated(wishlistItemMsg));
 	        
 	        // If the confirmation message is found, it means the item was successfully added to the cart
 	        return confirmationMessage.isDisplayed();  // Return true if the message is displayed
 	    } catch (NoSuchElementException  e) {
 	        // If the message is not found or the timeout is exceeded, return false
 	        return false;
 	    }
	}

    public void goToWishlist() throws InterruptedException {
    	Thread.sleep(5000);
        driver.findElement(wishlist).click();
        
    }

    public boolean isWishlistEmpty() {
        try {
            WebElement emptyMessage = driver.findElement(wishlistEmptyMessage);
            return emptyMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void getWishlistProductDetails() throws InterruptedException {
    	
    	WebDriverWait wait=new WebDriverWait(driver,5);
        List<WebElement> productElements = driver.findElements(wishlistProductDetails);
        
        wait.until(d->productElements.get(0).isDisplayed());
        System.out.println("Product names");
        for(WebElement pr:productElements) {
        	System.out.println("product Names:"+pr.getText());
        }
    }


	public void removeProductFromCart() throws InterruptedException {
		
		goToCart();
		WebDriverWait wait1 = new WebDriverWait(driver, 10);  // Explicit wait of 10 seconds (adjust as needed)
	    wait1.until(ExpectedConditions.elementToBeClickable(removeproduct)).click();
	    
	    WebDriverWait wait2 = new WebDriverWait(driver, 10);  // Explicit wait of 10 seconds (adjust as needed)
	    wait2.until(ExpectedConditions.elementToBeClickable(updateCart)).click();
	    
		
	}


	public void removeProductFromWishlist() throws InterruptedException {
		goToWishlist();
		
		WebDriverWait wait1 = new WebDriverWait(driver, 10);  // Explicit wait of 10 seconds (adjust as needed)
	    wait1.until(ExpectedConditions.elementToBeClickable(removeItem)).click();
	    
	    WebDriverWait wait2 = new WebDriverWait(driver, 10);  // Explicit wait of 10 seconds (adjust as needed)
	    wait2.until(ExpectedConditions.elementToBeClickable(updateWishlist)).click();
	    
	}
	
}

    

	
	
	
	