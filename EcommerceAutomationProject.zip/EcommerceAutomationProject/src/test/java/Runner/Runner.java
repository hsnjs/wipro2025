package Runner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = {"src/test/resources/Parallel/shopping_cart.feature"},  // Use relative path for feature files
    glue = {"Parallel"},  // Ensure this matches your step definitions package
    dryRun = false,  // Set to false to actually run the tests
    monochrome = true,
    tags = "@Sanity",  // Ensure you have scenarios tagged with @Sanity
    plugin = {
        "pretty",
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",  // Extent report plugin
        "timeline:test-output-thread/"
    }
)
public class Runner {
}
