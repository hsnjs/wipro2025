package Parallel;

import org.openqa.selenium.WebDriver;


import com.pages.EcommercePage;
import com.qa.factory.DriverFactory;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.After;
import static org.junit.Assert.*;

import java.util.List;

public class EcommerceSD {

    private WebDriver driver;
    private EcommercePage ecommercePage= new EcommercePage(DriverFactory.getDriver());
  
    // Setup WebDriver instance and initialize the EcommercePage class
    @Given("I am user is on login page")
    public void I_am_user_is_on_login_page() {
        // Initialize WebDriver (assuming ChromeDriver is used here)
        WebDriver driver=DriverFactory.getDriver();
        
        driver.get("https://demowebshop.tricentis.com/login");  // Replace with actual URL of your e-commerce site
        
    }
    @Then("user enters username {string}")
    public void user_enters_username(String username) { 
        // Log in with valid user credentials
        ecommercePage.enterusername(username);  // Replace with actual credentials
    }
    @Then("user enters password {string}")
    public void user_enter_password(String password) {
    	ecommercePage.enterpassword(password);
    }

    @When ("user clicks on login button")
    public void user_clicks_on_login_button() {
    	ecommercePage.login();
    }
    // Scenario 1: Add item to shopping cart
    @When("I add an item to the shopping cart")
    public void i_add_an_item_to_the_shopping_cart() throws InterruptedException {
        ecommercePage.addItemToCart(); // Add the first product (index) to the cart
    }


    @Then("I should see items in the cart")
    public void i_should_see_items_in_the_cart() {
        boolean isItemInCart = ecommercePage.isItemInCart();
        
        assertTrue(isItemInCart);
    }

    // Scenario 2: Shopping cart is empty
    @When("I go to the shopping cart without adding any items")
    public void i_go_to_the_shopping_cart_without_adding_any_items() throws InterruptedException {
        ecommercePage.goToCart(); // Navigate to the shopping cart without adding any items
    }

    @Then("I should see a message indicating that the cart is empty")
    public void i_should_see_a_message_indicating_that_the_cart_is_empty() {
        boolean isCartEmptyMessageDisplayed = ecommercePage.isCartEmpty();   
        assertTrue(isCartEmptyMessageDisplayed);
    }

    //Scenario 3: Getting quantity of products in cart
    
    @When("I go to the shopping cart")
    public void I_go_to_the_shopping_cart() throws InterruptedException {
    	ecommercePage.goToCart();
    	
    }
    @Then("I should see the price of the item as in the cart")
    public void i_should_see_the_price_of_the_item_as_in_the_cart() {
       String price=ecommercePage.getItemPrice(); // Get the quantity of the first item in the cart
       System.out.println("Total price of items in cart: " + price);
    }

    // Scenario 4: Add products to wishlist
    @When("I add a product to my wishlist")
    public void i_add_a_product_to_my_wishlist() throws InterruptedException {
    	ecommercePage.addProductToWishlist(); // Add the  product to wishlist
    }

    @Then("I should see the added product in my wishlist")
    public void i_should_see_the_added_product_in_my_wishlist() throws InterruptedException {
        boolean isProductInWishlist = ecommercePage.isProductInWishlist();
        assertTrue(isProductInWishlist);
    }

    // Scenario 5: Wishlist is empty
    @When("I go to the wishlist without adding any products")
    public void i_go_to_the_wishlist_without_adding_any_products() throws InterruptedException {
        ecommercePage.goToWishlist(); // Navigate to the wishlist without adding any products
    }

    @Then("I should see a message indicating that the wishlist is empty")
    public void i_should_see_a_message_indicating_that_the_wishlist_is_empty() {
        boolean isWishlistEmptyMessageDisplayed = ecommercePage.isWishlistEmpty();
        assertTrue("Empty wishlist message should be displayed", isWishlistEmptyMessageDisplayed);
    }

    //Scenario 6
    @When("user go to the wishlist")
    public void user_go_to_the_wishlist() throws InterruptedException {
    	ecommercePage.goToWishlist();
    }
    @Then("user should see the product names in the wishlist")
    public void i_should_see_all_the_added_products_in_the_wishlist() throws InterruptedException {
        ecommercePage.getWishlistProductDetails();
        
    }
    //Scenario 7: remove from cart
   @Then("I should remove the product from cart")
   public void I_should_remove_the_product_from_cart() throws InterruptedException {
	   ecommercePage.removeProductFromCart();
   }
   
   //Scenario 8:remove from wishlist
   @Then("user should remove the product from wishlist")
   public void  user_should_remove_the_product_from_wishlist() throws InterruptedException {
	   ecommercePage.removeProductFromWishlist();
   }
}




















































































































































































































































































































































































