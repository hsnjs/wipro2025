package Config;

public class RestfulApiEndpoints {

	
	 // Endpoint to get a list of posts
    public String ALL_OBJECTS = "/objects";

    // Endpoint to get a single post by ID
    public String SINGLE_OBJECT = "/objects/{objectsId}";
}
