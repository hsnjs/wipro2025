package APITests;


import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;

import org.junit.jupiter.api.Test;

import Config.RestfulApiConfig;




public class GetRequest extends RestfulApiConfig {
	
	@Test
	public void verifygetrequest() {
		setup();
		
		RestAssured.given()
        .log().all()
        .when()
        .get(ALL_OBJECTS)  // Will get all objects
        .then()
        .log().all();
	}

}
