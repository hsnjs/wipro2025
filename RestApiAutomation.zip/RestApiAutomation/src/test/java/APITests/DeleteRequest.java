package APITests;

import org.junit.jupiter.api.Test;

import Config.RestfulApiConfig;
import io.restassured.RestAssured;





public class DeleteRequest extends RestfulApiConfig{

	@Test
	public void verifydeleterequest() {
		
		setup();
		
		RestAssured.given().log().all().when().delete(SINGLE_OBJECT,1)
		.then().log().all().statusCode(200);
	}
}
