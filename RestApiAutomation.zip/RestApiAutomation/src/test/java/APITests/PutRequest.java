package APITests;



import org.junit.jupiter.api.Test;

import Config.RestfulApiConfig;
import io.restassured.RestAssured;

public class PutRequest extends  RestfulApiConfig {
	
	@Test
	public void verifyputrequest() {
		
	
		String json="{\r\n"
				+ "   \"name\": \"Apple MacBook Pro 16\",\r\n"
				+ "   \"data\": {\r\n"
				+ "      \"year\": 2019,\r\n"
				+ "      \"price\": 2049.99,\r\n"
				+ "      \"CPU model\": \"Intel Core i9\",\r\n"
				+ "      \"Hard disk size\": \"1 TB\",\r\n"
				+ "      \"color\": \"silver\"\r\n"
				+ "   }\r\n"
				+ "}";
	setup();
	
	RestAssured.given().body(json).log().all()
    .when().put("https://api.restful-api.dev/objects/{id}", 1)
    .then().log().all()
    .statusCode(200); // Status Code 200 OK

	
	}
	

}
