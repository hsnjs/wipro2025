package APITests;

import org.junit.jupiter.api.Test;

import Config.RestfulApiConfig;
import io.restassured.response.Response;
import io.restassured.RestAssured;
import org.junit.Assert;

public class PostRequest extends RestfulApiConfig {
    
    @Test
    public void verifypostrequest() {
        
       setup();
        
        String json = "{\r\n"
                + "   \"name\": \"Samsung A5\",\r\n"
                + "   \"data\": {\r\n"
                + "      \"year\": 2019,\r\n"
                + "      \"price\": 1849.99,\r\n"
                + "      \"CPU model\": \"Intel Core i9\",\r\n"
                + "      \"Hard disk size\": \"1 TB\"\r\n"
                + "   }\r\n"
                + "}";

        // Send the POST request and capture the response
        Response response = RestAssured.given()
                .body(json)                // The body contains the JSON data for the new object
                .log().all()                // Logs the request details
                .when()
                .post(ALL_OBJECTS);
        
        // Log the response body and status code
        response.then().log().all().statusCode(200);  // Expecting HTTP status code 200 or 201
        System.out.println("Response body: " + response.getBody().asString());
        
        // Extract the 'id' from the response using JSON path
        String extractedId = response.jsonPath().getString("id");
        
        // Optionally, assert that the ID is not null or empty
        Assert.assertNotNull("ID should not be null", extractedId);
        Assert.assertFalse("ID should not be empty", extractedId.isEmpty());
        
        // Print the extracted ID
        System.out.println("Extracted ID: " + extractedId);
    }
}
