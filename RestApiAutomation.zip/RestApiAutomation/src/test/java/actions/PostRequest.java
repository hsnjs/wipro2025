package actions;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostRequest {

    public static Response sendPostRequest(String endpoint) {
    	
    	String json="{\r\n"
				+ "   \"name\": \"Apple MacBook Pro 16\",\r\n"
				+ "   \"data\": {\r\n"
				+ "      \"year\": 2019,\r\n"
				+ "      \"price\": 1849.99,\r\n"
				+ "      \"CPU model\": \"Intel Core i9\",\r\n"
				+ "      \"Hard disk size\": \"1 TB\"\r\n"
				+ "   }\r\n"
				+ "}";
	
        // Build the request
        RequestSpecification request = RestAssured.given()
                .contentType(ContentType.JSON)
                .body(json); // Set request body if needed

        // Send the POST request
        return request.when().post(endpoint);
    }
}
