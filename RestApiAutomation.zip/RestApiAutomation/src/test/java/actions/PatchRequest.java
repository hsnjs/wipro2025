package actions;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PatchRequest {

	
public static Response sendPatchRequest(String endpoint) {
    	
    	String json="{\r\n"
    			+ "   \"name\": \"Apple MacBook Pro 16 (Updated Name)\"\r\n"
    			+ "}";
	
        // Build the request
        RequestSpecification request = RestAssured.given()
                .contentType(ContentType.JSON)
                .body(json); // Set request body if needed

        // Send the POST request
        return request.when().post(endpoint);
    }
}
