package steps;

import actions.PatchRequest;
import actions.PostRequest;
import actions.PutRequest;
import io.cucumber.java.en.Given;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;



public class StepDefinitions {

    private Response response;

    @Given("I have the endpoint {string}")
    public void i_have_the_endpoint(String endpoint) {
        // Store the endpoint or use it directly in the request
        RestAssured.baseURI = "https://api.restful-api.dev"; // Set the base URI (adjust based on the actual API)
        System.out.println("Request URL: "+ RestAssured.baseURI + endpoint);
    }

    @When("I send a GET request")
    public void i_send_a_get_request() {
        // This step is already performed in the @Given step, so no need to do it again here.
    	response=RestAssured.given()
                .when()
                .get("/objects"); // Adjust endpoint path here
    }

    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(int statusCode) {
       response.then().statusCode(statusCode);
    }

    //delete.feature
    @When("I send a delete request {string}")
    public void I_send_a_delete_request(String id) {
    	response=RestAssured.given().when()
    			.delete("https://api.restful-api.dev/objects/{objectid}",id);
    }
    
    //post feature
    @When("I send a post request {string}")
    public void i_send_a_post_request(String endpoint) {
    	response = PostRequest.sendPostRequest(endpoint);
       
    }
    //put feature
    @When("I send a put request {string}")
    public void i_send_a_put_request(String endpoint) {
    	response = PutRequest.sendPutRequest(endpoint);
       
    }
    
    //patch feature
    @When("I send a patch request {string}")
    public void i_send_a_patch_request(String endpoint) {
    	response = PatchRequest.sendPatchRequest(endpoint);
       
    }

}
