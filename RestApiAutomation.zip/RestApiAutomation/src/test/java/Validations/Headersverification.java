package Validations;

import java.util.List;

import org.junit.jupiter.api.Test;

import Config.RestfulApiConfig;
import io.restassured.RestAssured;

import io.restassured.http.Headers;
import io.restassured.response.Response;

public class Headersverification extends RestfulApiConfig{

	
	@Test
	public void verifyHeader() throws InterruptedException {
		setup();
		Response res=RestAssured.given().log().all()
				.when().get(ALL_OBJECTS).then().extract().response();
		
		List<String> names=RestAssured.given().log()
				.all().when().get(ALL_OBJECTS).jsonPath()
				.getList("name");
		Thread.sleep(2000);
		Headers headers=res.getHeaders();
		
		System.out.println("headers"+headers);
		String ct=res.getContentType();
		System.out.println(ct);
	}
}
