package Validations;

import java.util.List;

import org.junit.jupiter.api.Test;


import Config.RestfulApiConfig;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ExtractObjectvalues extends RestfulApiConfig{
	
	@Test
	public  void verifyobjectextract() throws InterruptedException {
		
		setup();
		Response res=RestAssured.given().log().all()
				.when().get(ALL_OBJECTS).then().extract().response();
		
		List<String> names=RestAssured.given().log()
				.all().when().get(ALL_OBJECTS).jsonPath()
				.getList("name");
		Thread.sleep(2000);
		
		System.out.println(names);
		
		String oneTitle=RestAssured.given().when()
				.get(ALL_OBJECTS).jsonPath().getString("name[0]");
		
		
		System.out.println(oneTitle);
		
		String jsonstring=res.asString();
		
		if(jsonstring.contains("MacBook Pro")) {
			System.out.println("The name  MacBook Prois present");
		}else {
			System.out.println("The name MacBook Pro is not  present");
		}
		
	}

}
