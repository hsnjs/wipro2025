package Validations;

import org.junit.jupiter.api.Test;

import Config.RestfulApiConfig;
import io.restassured.RestAssured;
import io.restassured.response.ValidatableResponse;

public class StatusCodeVerf  extends RestfulApiConfig {
	
	@Test
	public void verifystatuscode() {
		
		setup();
		ValidatableResponse res=RestAssured.given().when()
				.get(ALL_OBJECTS).then().statusCode(200);
		
		System.out.println(res);
	}

}
