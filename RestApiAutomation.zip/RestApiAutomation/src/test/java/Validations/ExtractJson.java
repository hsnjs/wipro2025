package Validations;

import org.junit.jupiter.api.Test;


import Config.RestfulApiConfig;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ExtractJson extends RestfulApiConfig{
	
	@Test
	public  void verifyjsonExtract() {
		setup();
		Response res=RestAssured.given().log().all()
				.when().get(ALL_OBJECTS).then().extract().response();
		
		String jsonstring=res.asString();
		System.out.println(jsonstring);
		
	}
}
