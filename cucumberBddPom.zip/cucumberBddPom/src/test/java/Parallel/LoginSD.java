package Parallel;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.pages.LoginPage;
import com.qa.factory.DriverFactory;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class LoginSD {

    private static String title;
    private LoginPage login = new LoginPage(DriverFactory.getDriver());

    @Given("user is on login page")
    public void user_is_on_login_page() throws InterruptedException {
        WebDriver driver = DriverFactory.getDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        
       Thread.sleep(4000);
    }

    @When("user gets the title of the page")
    public void user_gets_the_title_of_the_page() {
        title = login.getLoginPageTitle();
        System.out.println(title);
    }

    @Then("page title should be {string}")
    public void page_title_should_be(String expectedtitlename) {
    	Assert.assertEquals("Title does not match!", expectedtitlename, title);

    }
    @Then("user gets redirects to dashboard")
    public void user_gets_redirects_to_dashboard() {
    	 String currentUrl = DriverFactory.getDriver().getCurrentUrl();
         System.out.println("Dashboard url:"+currentUrl);
    }
    @Then("user sees an Alert error")
    public void user_sees_Alert_error() throws InterruptedException {
    	Thread.sleep(2000);
    	login.verifyerrormsg();
    	
    }
    @When("user enters username {string}")
    public void user_enters_username(String username) {
        login.enteruserrname(username);
    }

    @When("user enters password {string}")
    public void user_enters_password(String password) {
        login.enterpassword(password);
    }

    @When("user clicks on login button")
    public void user_clicks_on_login_button() {
        login.clicklogin();
    }

    @Then("user gets the title of the home page")
    public void user_gets_the_title_of_the_home_page() {
        title = login.getLoginPageTitle();
        System.out.println(title);
    }
    
    @Then("user checks the logo is visible")
    public void theLogoIsVisible() {
        boolean logo=login.getLogoisVisible();// Use the appropriate ID or selector for the logo
        Assert.assertTrue("Logo is not visible", logo);
    }
    
    @When("user checks the Forgot Password link is visible")
    public void forgotpwdLink_isvisible1() {
        boolean isForgotPasswordVisible = login.isForgotPasswordLinkVisible();
        Assert.assertTrue("Forgot Password link is not visible", isForgotPasswordVisible);
    }
    
    @When("user clicks on forgot password link")
    public void user_clicks_on_forgot_password_link() {
        login.clickForgotPasswordLink();
    }
   
    
    @Then("user should be redirected to forgot password link")
    public void user_should_be_redirected_to_forgot_password_link() {
        // Verify that we have been redirected to the Forgot Password page.
        // You can either check the title of the page or the URL to confirm the redirection.
        String currentUrl = DriverFactory.getDriver().getCurrentUrl();
        System.out.println("Forgot password link:"+currentUrl);
        Assert.assertTrue("User is not redirected to the Forgot Password page", currentUrl.contains("orangehrmlive"));
    }

    // Scenario: Verify Youtube Media Link
    
    @When("user checks the Youtube media link is visible")
    public void user_checks_the_social_media_link_is_visible() {
        boolean isSocialMediaLinkVisible = login.isSocialMediaLinkVisible();
        Assert.assertTrue("Youtube link is not visible", isSocialMediaLinkVisible);
    }
    @When("user clicks on Youtube media link")
    public void user_clicks_on_social_media_link() {
        login.clickSocialMediaLink();
    }
    
    @Then("user redirects to YouTube media link")
    public void user_redirects_to_social_media_link() {
        // Verify that we have been redirected to the YouTube Media link.
        // You can either check the title of the page or the URL to confirm the redirection.
        String currentUrl = DriverFactory.getDriver().getCurrentUrl();
        System.out.println("youtube link"+currentUrl);
        Assert.assertTrue("User is not redirected to the Social Media page", currentUrl.contains("orangehrmlive"));
    }
}

