package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	
	
	private WebDriver driver;
	
	// locators 
	
	private By username1 = By.xpath("//input[@placeholder='Username']");
	private By password1=By.xpath("//input[@name = 'password']");
	private By submit=By.xpath("//button[@type='submit']");
	private By forgotpwd=By.xpath("//div[@class='orangehrm-login-forgot']");
	private By logo=By.xpath("//div[@class='orangehrm-login-slot-wrapper']");
	private By socialMediaLink=By.xpath("//a[@href='https://www.youtube.com/c/OrangeHRMInc']//*[name()='svg']//*[name()='g' and contains(@fill,'currentCol')]");
	private By errormsg=By.xpath("//p[@class='oxd-text oxd-text--p oxd-alert-content-text']");
	// constructor 
	
	public LoginPage(WebDriver driver) {
		
		this.driver= driver;
	}
	
	public String getLoginPageTitle() {
		return driver.getTitle();
		
	}
	
	public void  enteruserrname(String username) {
		
		driver.findElement(username1).sendKeys(username);


		
	}
	
	public void  enterpassword(String password) {
		
		driver.findElement(password1).sendKeys(password);


		
	}
	
	public void  clicklogin() {
		
		driver.findElement(submit).click();


		
	}

	public boolean  getLogoisVisible() {
		return driver.findElement(logo).isDisplayed();	
	}
	
	public boolean isForgotPasswordLinkVisible() {
		return driver.findElement(forgotpwd).isDisplayed();
	}
	
	public void clickForgotPasswordLink() {
		driver.findElement(forgotpwd).click();
	}

	public boolean isSocialMediaLinkVisible() {
		
		return driver.findElement(socialMediaLink).isDisplayed();
	}
	
	public void clickSocialMediaLink() {
		driver.findElement(socialMediaLink).click();
	}

	public void verifyerrormsg() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(3000);
		driver.findElement(errormsg).isDisplayed();
		
	}

	
	
	

	

}
